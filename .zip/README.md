# magna-promotion
 Magna Q4 promo
